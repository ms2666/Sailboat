function [] = setVecData(x)
global dataSet;
dataSet = x;
end

