function [ r ] = getVecData()
global dataSet;
r = dataSet;
end